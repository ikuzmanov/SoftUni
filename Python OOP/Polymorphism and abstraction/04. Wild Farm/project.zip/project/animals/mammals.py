from project.animals.animal import Mammal


class Mouse(Mammal):
    pass


class Tiger(Mammal):
    pass


class Cat(Mammal):
    pass


class Dog(Mammal):
    pass
