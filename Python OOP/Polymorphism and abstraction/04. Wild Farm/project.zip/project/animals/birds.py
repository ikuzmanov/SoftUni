from project.animals.animal import Bird


class Owl(Bird):
    pass


class Hen(Bird):
    pass